#!/usr/bin/env node
/**
 * Собирает src/ в один автономный файл index.html:
 * CSS и JS встроены, ES-модули склеены в один скрипт, CSP считается по хэшам.
 *
 * Зачем: ES-модули браузеры не загружают с file://, а значит страница не открывается
 * двойным кликом. Собранный файл работает откуда угодно: с диска, с сервера, с GitHub Pages.
 *
 *   npm run build
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SRC = path.join(ROOT, 'src');
export const OUTPUT = path.join(ROOT, 'index.html');

// Порядок важен: модуль идёт после тех, от которых зависит.
const MODULE_ORDER = [
  'weather-codes', 'format', 'model', 'storage', 'api', 'ui', 'autocomplete', 'main',
];

const read = (relative) => readFileSync(path.join(SRC, relative), 'utf8').replace(/\r\n/g, '\n');

const inlineText = (code) => `\n${code}\n`; // ровно то, что окажется между тегами
const sha256 = (text) => `'sha256-${createHash('sha256').update(text, 'utf8').digest('base64')}'`;

function stripModuleSyntax(name, code) {
  const result = code
    .replace(/^import[\s\S]*?\bfrom\s+['"][^'"]+['"];?[ \t]*\n/gm, '')
    .replace(/^export\s+(?=(?:async\s+)?(?:function|class|const|let)\b)/gm, '');
  if (/^\s*(import|export)\b/m.test(result)) {
    throw new Error(`${name}.js: сборщик не поддерживает этот синтаксис модулей`);
  }
  return result;
}

/** Все модули в одном классическом скрипте (IIFE). */
export function buildBundle() {
  const parts = MODULE_ORDER.map((name) => {
    const code = stripModuleSyntax(name, read(`js/${name}.js`)).trim();
    // В main.js было `import * as storage` — воспроизводим объект вручную.
    const prelude = name === 'main' ? 'const storage = { load, save };\n' : '';
    return `// ---- ${name}.js ----\n${prelude}${code}`;
  });
  return `(() => {\n'use strict';\n\n${parts.join('\n\n')}\n})();`;
}

/** Собирает итоговый HTML (строкой, без записи на диск). */
export function buildHtml() {
  let html = read('index.html');
  const css = read('css/styles.css').trim();
  const themeInit = read('js/theme-init.js').trim();
  const bundle = buildBundle();

  if (bundle.includes('</script')) throw new Error('В бандле найден «</script» — это сломает inline-скрипт');

  const replace = (needle, replacement) => {
    if (!html.includes(needle)) throw new Error(`В src/index.html не найден фрагмент: ${needle}`);
    html = html.replace(needle, () => replacement); // функция — чтобы «$&» в коде не трактовалось особо
  };

  replace('<link rel="stylesheet" href="css/styles.css">', `<style>${inlineText(css)}</style>`);
  replace('<script src="js/theme-init.js"></script>', `<script>${inlineText(themeInit)}</script>`);
  replace('<script type="module" src="js/main.js"></script>\n', '');
  replace('</body>', `<script>${inlineText(bundle)}</script>\n</body>`);
  replace('<!doctype html>', '<!doctype html>\n<!-- Файл создан командой «npm run build» из папки src/. Не редактируйте его вручную. -->');

  const csp = [
    "default-src 'none'",
    `script-src ${sha256(inlineText(themeInit))} ${sha256(inlineText(bundle))}`,
    `style-src ${sha256(inlineText(css))}`,
    'img-src data:',
    'connect-src https://geocoding-api.open-meteo.com https://api.open-meteo.com https://api.bigdatacloud.net',
    "base-uri 'none'",
    "form-action 'none'",
  ].join('; ');

  html = html.replace(/<meta http-equiv="Content-Security-Policy"[^>]*>/, () =>
    `<meta http-equiv="Content-Security-Policy" content="${csp}">`);

  verifyCsp(html);
  return html;
}

/** Проверяет, что хэши в CSP совпадают с реальным содержимым inline-скриптов и стилей. */
export function verifyCsp(html) {
  const meta = html.match(/<meta http-equiv="Content-Security-Policy" content="([^"]*)"/);
  if (!meta) throw new Error('В собранном файле нет CSP');
  const csp = meta[1];

  const inline = [
    ...[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]),
    ...[...html.matchAll(/<style>([\s\S]*?)<\/style>/g)].map((m) => m[1]),
  ];
  if (inline.length !== 3) throw new Error(`Ожидалось 3 inline-блока, найдено ${inline.length}`);
  for (const text of inline) {
    if (!csp.includes(sha256(text))) throw new Error('Хэш inline-блока не найден в CSP');
  }
  if (/<script[^>]+src=/.test(html) || /<link[^>]+rel="stylesheet"/.test(html)) {
    throw new Error('В собранном файле остались внешние скрипты или стили');
  }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const html = buildHtml();
  writeFileSync(OUTPUT, html);
  console.log(`Готово: ${path.relative(process.cwd(), OUTPUT)} (${(html.length / 1024).toFixed(1)} КБ)`);
}
