import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { buildBundle, buildHtml, verifyCsp, OUTPUT } from '../scripts/build.mjs';

test('бандл — синтаксически корректный классический скрипт', () => {
  assert.doesNotThrow(() => new vm.Script(buildBundle()));
});

test('в бандле не осталось import/export', () => {
  assert.doesNotMatch(buildBundle(), /^\s*(import|export)\b/m);
});

test('в собранном HTML нет внешних файлов и верные CSP-хэши', () => {
  const html = buildHtml();
  assert.doesNotThrow(() => verifyCsp(html));
  assert.doesNotMatch(html, /type="module"/);
});

test('verifyCsp замечает подмену содержимого', () => {
  const tampered = buildHtml().replace('(() => {', '(() => { /* изменено */');
  assert.throws(() => verifyCsp(tampered), /Хэш/);
});

test('index.html в репозитории актуален (иначе выполните: npm run build)', () => {
  assert.equal(readFileSync(OUTPUT, 'utf8'), buildHtml());
});
