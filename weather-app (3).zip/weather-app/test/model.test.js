import { test } from 'node:test';
import assert from 'node:assert/strict';
import { normalizeForecast, pickHourly, placeId } from '../src/js/model.js';
import { makeRawForecast } from './fixtures.js';

test('placeId округляет координаты', () => {
  assert.equal(placeId({ latitude: 55.7558, longitude: 37.6173 }), '55.76,37.62');
  assert.equal(
    placeId({ latitude: 55.7561, longitude: 37.6171 }),
    placeId({ latitude: 55.7558, longitude: 37.6173 }),
  );
});

test('pickHourly начинает с текущего часа и берёт 24 значения', () => {
  const { hourly, current } = makeRawForecast();
  const result = pickHourly(hourly, current.time, 24);

  assert.equal(result.length, 24);
  assert.equal(result[0].time, '2026-10-05T14:00');
  assert.equal(result[23].time, '2026-10-06T13:00');
});

test('pickHourly не выходит за пределы массива', () => {
  const { hourly } = makeRawForecast();
  const result = pickHourly(hourly, '2026-10-06T20:30', 24);
  assert.equal(result.length, 4); // 20:00, 21:00, 22:00, 23:00
});

test('pickHourly: если текущий час не найден, начинает с начала', () => {
  const { hourly } = makeRawForecast();
  const result = pickHourly(hourly, '2030-01-01T00:00', 3);
  assert.equal(result[0].time, '2026-10-05T00:00');
  assert.equal(result.length, 3);
});

test('normalizeForecast приводит ответ API к модели интерфейса', () => {
  const data = normalizeForecast(makeRawForecast());

  assert.equal(data.current.temp, 12.4);
  assert.equal(data.current.feelsLike, 10.1);
  assert.equal(data.current.isDay, true);
  assert.equal(data.current.windDir, 225);
  assert.equal(data.hourly.length, 24);
  assert.equal(data.daily.length, 7);
  assert.deepEqual(data.daily[0], {
    date: '2026-10-05',
    code: 61,
    max: 14,
    min: 4,
    sunrise: '2026-10-05T06:48',
    sunset: '2026-10-05T18:12',
    uv: 2.4,
    precip: 0,
  });
});

test('normalizeForecast бросает ошибку на некорректном ответе', () => {
  assert.throws(() => normalizeForecast(null), /неожиданный ответ/);
  assert.throws(() => normalizeForecast({}), /неожиданный ответ/);
  assert.throws(() => normalizeForecast({ current: {}, hourly: {}, daily: {} }), /неожиданный ответ/);
});
