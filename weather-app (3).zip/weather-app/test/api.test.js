import { test, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { searchCities, getForecast, reverseGeocode, clearCache, ApiError } from '../src/js/api.js';
import { makeRawForecast } from './fixtures.js';

const realFetch = globalThis.fetch;
const moscow = { name: 'Москва', latitude: 55.7558, longitude: 37.6173 };
let requests;

function mockFetch(handler) {
  globalThis.fetch = async (url, options) => {
    requests.push(String(url));
    return handler(String(url), options);
  };
}

const jsonResponse = (body, status = 200) => ({
  ok: status >= 200 && status < 300,
  status,
  json: async () => body,
});

beforeEach(() => {
  requests = [];
  clearCache();
});

afterEach(() => {
  globalThis.fetch = realFetch;
});

test('searchCities не ходит в сеть при коротком запросе', async () => {
  mockFetch(() => jsonResponse({}));
  assert.deepEqual(await searchCities('м'), []);
  assert.deepEqual(await searchCities('   '), []);
  assert.equal(requests.length, 0);
});

test('searchCities формирует запрос и нормализует результат', async () => {
  mockFetch(() => jsonResponse({
    results: [
      { name: 'Москва', admin1: 'Москва', country: 'Россия', latitude: 55.75, longitude: 37.62, id: 1 },
      { name: 'Moscow', latitude: 46.73, longitude: -117, id: 2 },
    ],
  }));

  const cities = await searchCities('  Москва ');
  const url = new URL(requests[0]);

  assert.equal(url.hostname, 'geocoding-api.open-meteo.com');
  assert.equal(url.searchParams.get('name'), 'Москва');
  assert.equal(url.searchParams.get('language'), 'ru');
  assert.deepEqual(cities[0], {
    name: 'Москва', region: 'Москва', country: 'Россия', latitude: 55.75, longitude: 37.62,
  });
  assert.equal(cities[1].region, ''); // отсутствующие поля заменяются пустой строкой
});

test('searchCities возвращает [] если ничего не найдено', async () => {
  mockFetch(() => jsonResponse({ generationtime_ms: 0.4 })); // API не присылает results
  assert.deepEqual(await searchCities('ыыыыы'), []);
});

test('getForecast передаёт координаты и единицы измерения', async () => {
  mockFetch(() => jsonResponse(makeRawForecast()));

  await getForecast(moscow, 'imperial');
  const url = new URL(requests[0]);

  assert.equal(url.hostname, 'api.open-meteo.com');
  assert.equal(url.searchParams.get('latitude'), '55.7558');
  assert.equal(url.searchParams.get('longitude'), '37.6173');
  assert.equal(url.searchParams.get('temperature_unit'), 'fahrenheit');
  assert.equal(url.searchParams.get('wind_speed_unit'), 'mph');
  assert.equal(url.searchParams.get('timezone'), 'auto');
  assert.equal(url.searchParams.get('forecast_days'), '7');
});

test('getForecast возвращает нормализованную модель', async () => {
  mockFetch(() => jsonResponse(makeRawForecast()));
  const data = await getForecast(moscow, 'metric');
  assert.equal(data.daily.length, 7);
  assert.equal(data.hourly.length, 24);
  assert.equal(data.current.temp, 12.4);
});

test('getForecast кэширует ответ, но отдельно для каждых единиц', async () => {
  mockFetch(() => jsonResponse(makeRawForecast()));

  await getForecast(moscow, 'metric');
  await getForecast(moscow, 'metric');
  assert.equal(requests.length, 1);

  await getForecast(moscow, 'imperial');
  assert.equal(requests.length, 2);
});

test('HTTP-ошибка превращается в ApiError со статусом', async () => {
  mockFetch(() => jsonResponse({}, 503));
  await assert.rejects(
    () => getForecast(moscow, 'metric'),
    (err) => err instanceof ApiError && err.status === 503,
  );
});

test('ошибка в ответе не попадает в кэш', async () => {
  mockFetch(() => jsonResponse({}, 500));
  await assert.rejects(() => getForecast(moscow, 'metric'));

  mockFetch(() => jsonResponse(makeRawForecast()));
  const data = await getForecast(moscow, 'metric');
  assert.equal(data.daily.length, 7);
});

test('сетевой сбой превращается в понятный ApiError', async () => {
  mockFetch(() => { throw new TypeError('Failed to fetch'); });
  await assert.rejects(
    () => getForecast(moscow, 'metric'),
    (err) => err instanceof ApiError && /соединения/.test(err.message),
  );
});

test('AbortError пробрасывается как есть и не считается ошибкой сервиса', async () => {
  mockFetch(() => { throw new DOMException('Aborted', 'AbortError'); });
  await assert.rejects(
    () => getForecast(moscow, 'metric'),
    (err) => err.name === 'AbortError',
  );
});

test('reverseGeocode возвращает null при ошибке, а не бросает исключение', async () => {
  mockFetch(() => jsonResponse({}, 500));
  assert.equal(await reverseGeocode(55.75, 37.62), null);
});

test('reverseGeocode достаёт город из ответа', async () => {
  mockFetch(() => jsonResponse({
    city: 'Казань', principalSubdivision: 'Татарстан', countryName: 'Россия',
  }));
  assert.deepEqual(await reverseGeocode(55.79, 49.12), {
    name: 'Казань', region: 'Татарстан', country: 'Россия',
  });
});
