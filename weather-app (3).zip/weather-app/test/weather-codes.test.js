import { test } from 'node:test';
import assert from 'node:assert/strict';
import { getWeatherInfo } from '../src/js/weather-codes.js';

test('известный код возвращает подпись и иконку', () => {
  const info = getWeatherInfo(63, true);
  assert.equal(info.label, 'Дождь');
  assert.equal(info.theme, 'rain');
  assert.ok(info.icon);
});

test('ночью ясная погода получает ночную иконку и тему', () => {
  const day = getWeatherInfo(0, true);
  const night = getWeatherInfo(0, false);
  assert.equal(day.theme, 'clear');
  assert.equal(night.theme, 'night');
  assert.notEqual(day.icon, night.icon);
});

test('для кодов без ночной иконки используется дневная', () => {
  assert.equal(getWeatherInfo(95, false).icon, getWeatherInfo(95, true).icon);
  assert.equal(getWeatherInfo(95, false).theme, 'storm');
});

test('неизвестный код не ломает интерфейс', () => {
  const info = getWeatherInfo(12345);
  assert.equal(info.label, 'Нет данных');
  assert.equal(info.theme, 'cloudy');
});
