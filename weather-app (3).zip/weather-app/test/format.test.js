import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  formatTemp, windDirection, hPaToMmHg, formatClock, formatHourLabel,
  formatWeekday, formatDate, uvLabel, rangePosition, debounce,
} from '../src/js/format.js';

test('formatTemp округляет и использует типографский минус', () => {
  assert.equal(formatTemp(21.6), '22°');
  assert.equal(formatTemp(-4.5), '−4°');
  assert.equal(formatTemp(-12.2), '−12°');
  assert.equal(formatTemp(0), '0°');
});

test('formatTemp не показывает «−0°» и обрабатывает пустые значения', () => {
  assert.equal(formatTemp(-0.4), '0°');
  assert.equal(formatTemp(null), '—');
  assert.equal(formatTemp(undefined), '—');
  assert.equal(formatTemp(NaN), '—');
});

test('windDirection переводит градусы в стороны света', () => {
  assert.equal(windDirection(0), 'С');
  assert.equal(windDirection(90), 'В');
  assert.equal(windDirection(180), 'Ю');
  assert.equal(windDirection(225), 'ЮЗ');
  assert.equal(windDirection(350), 'С');
  assert.equal(windDirection(360), 'С');
  assert.equal(windDirection(-90), 'З');
  assert.equal(windDirection(null), '');
});

test('hPaToMmHg: нормальное давление ≈ 760 мм рт. ст.', () => {
  assert.equal(hPaToMmHg(1013), 760);
  assert.equal(hPaToMmHg(1000), 750);
});

test('время города берётся из строки, без сдвига часового пояса', () => {
  assert.equal(formatClock('2026-10-05T14:30'), '14:30');
  assert.equal(formatHourLabel('2026-10-05T14:00', 0), 'Сейчас');
  assert.equal(formatHourLabel('2026-10-05T15:00', 1), '15:00');
});

test('formatWeekday: сегодня, завтра, затем дни недели', () => {
  assert.equal(formatWeekday('2026-10-05', 0), 'Сегодня');
  assert.equal(formatWeekday('2026-10-06', 1), 'Завтра');
  assert.equal(formatWeekday('2026-10-07', 2), 'Ср'); // 7 октября 2026 — среда
  assert.equal(formatWeekday('2026-10-11', 6), 'Вс');
});

test('formatDate выводит день и месяц по-русски', () => {
  assert.equal(formatDate('2026-10-05T14:15'), '5 октября');
});

test('uvLabel соответствует шкале ВОЗ', () => {
  assert.equal(uvLabel(1), 'Низкий');
  assert.equal(uvLabel(4), 'Умеренный');
  assert.equal(uvLabel(7), 'Высокий');
  assert.equal(uvLabel(9), 'Очень высокий');
  assert.equal(uvLabel(12), 'Экстремальный');
  assert.equal(uvLabel(undefined), 'Низкий');
});

test('rangePosition считает позицию полоски в процентах', () => {
  assert.deepEqual(rangePosition(0, 10, 0, 20), { left: 0, width: 50 });
  assert.deepEqual(rangePosition(10, 20, 0, 20), { left: 50, width: 50 });
});

test('rangePosition: полоска не пропадает и не выходит за границы', () => {
  const same = rangePosition(5, 5, 5, 5); // нулевой диапазон недели — без NaN
  assert.ok(Number.isFinite(same.left) && Number.isFinite(same.width));

  const thin = rangePosition(20, 20, 0, 20);
  assert.ok(thin.width >= 6);
  assert.ok(thin.left + thin.width <= 100);
});

test('debounce вызывает функцию один раз с последними аргументами', async () => {
  const calls = [];
  const fn = debounce((value) => calls.push(value), 20);
  fn('a');
  fn('b');
  fn('c');
  await new Promise((resolve) => setTimeout(resolve, 60));
  assert.deepEqual(calls, ['c']);
});

test('debounce.cancel отменяет отложенный вызов', async () => {
  const calls = [];
  const fn = debounce((value) => calls.push(value), 20);
  fn('a');
  fn.cancel();
  await new Promise((resolve) => setTimeout(resolve, 50));
  assert.deepEqual(calls, []);
});
