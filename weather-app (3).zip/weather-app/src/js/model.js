/**
 * Превращает «сырой» ответ Open-Meteo в удобную для интерфейса модель.
 * Всё, что связано со структурой API, живёт здесь — UI про неё не знает.
 */

/** Стабильный идентификатор места (округляем, чтобы «почти те же» координаты совпадали). */
export function placeId(place) {
  return `${place.latitude.toFixed(2)},${place.longitude.toFixed(2)}`;
}

/**
 * Берёт `count` часов начиная с текущего.
 * Строки времени в ISO сравниваются лексикографически — это корректно.
 */
export function pickHourly(hourly, currentTime, count = 24) {
  const hourPrefix = currentTime.slice(0, 13); // «YYYY-MM-DDTHH»
  let start = hourly.time.findIndex((t) => t.slice(0, 13) >= hourPrefix);
  if (start === -1) start = 0;
  const end = Math.min(start + count, hourly.time.length);

  const result = [];
  for (let i = start; i < end; i += 1) {
    result.push({
      time: hourly.time[i],
      temp: hourly.temperature_2m[i],
      code: hourly.weather_code[i],
      isDay: hourly.is_day[i] === 1,
      precip: hourly.precipitation_probability[i],
    });
  }
  return result;
}

/** @throws {Error} если ответ не похож на прогноз */
export function normalizeForecast(raw) {
  const { current, hourly, daily } = raw ?? {};
  if (!current || !hourly?.time || !daily?.time) {
    throw new Error('Сервис вернул неожиданный ответ');
  }

  return {
    timezone: raw.timezone,
    current: {
      time: current.time,
      temp: current.temperature_2m,
      feelsLike: current.apparent_temperature,
      humidity: current.relative_humidity_2m,
      isDay: current.is_day === 1,
      code: current.weather_code,
      windSpeed: current.wind_speed_10m,
      windDir: current.wind_direction_10m,
      pressure: current.surface_pressure,
    },
    hourly: pickHourly(hourly, current.time, 24),
    daily: daily.time.map((date, i) => ({
      date,
      code: daily.weather_code[i],
      max: daily.temperature_2m_max[i],
      min: daily.temperature_2m_min[i],
      sunrise: daily.sunrise[i],
      sunset: daily.sunset[i],
      uv: daily.uv_index_max[i],
      precip: daily.precipitation_probability_max[i],
    })),
  };
}
