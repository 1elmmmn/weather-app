import { debounce } from './format.js';
import { h } from './ui.js';

/**
 * Поле поиска с подсказками по паттерну ARIA combobox:
 * дебаунс, отмена устаревших запросов, навигация стрелками, Enter, Escape.
 */
export function createAutocomplete({ input, list, fetchItems, renderItem, onSelect, delay = 300, minLength = 2 }) {
  let items = [];
  let lastQuery = '';
  let active = -1;
  let controller = null;
  let requestId = 0;

  function open() {
    list.hidden = false;
    input.setAttribute('aria-expanded', 'true');
  }

  function close() {
    list.hidden = true;
    input.setAttribute('aria-expanded', 'false');
    input.removeAttribute('aria-activedescendant');
    active = -1;
  }

  function setActive(index) {
    active = index;
    [...list.children].forEach((li, i) => {
      li.setAttribute('aria-selected', String(i === index));
      li.classList.toggle('is-active', i === index);
    });
    if (index >= 0) {
      const option = list.children[index];
      input.setAttribute('aria-activedescendant', option.id);
      option.scrollIntoView({ block: 'nearest' });
    } else {
      input.removeAttribute('aria-activedescendant');
    }
  }

  function showMessage(text) {
    items = [];
    active = -1;
    list.replaceChildren(h('li', { class: 'suggestions__msg', role: 'presentation' }, text));
    open();
  }

  function choose(index) {
    const item = items[index];
    if (!item) return;
    close();
    onSelect(item);
  }

  function show(newItems) {
    if (newItems.length === 0) {
      showMessage('Ничего не найдено');
      return;
    }
    items = newItems;
    active = -1;
    list.replaceChildren(...items.map((item, i) => h('li', {
      id: `${list.id}-option-${i}`,
      role: 'option',
      class: 'suggestions__item',
      'aria-selected': 'false',
      onmousedown: (event) => event.preventDefault(), // не терять фокус input до click
      onclick: () => choose(i),
    }, renderItem(item))));
    open();
  }

  async function query(text) {
    const q = text.trim();
    controller?.abort();
    if (q.length < minLength) {
      items = [];
      close();
      return null;
    }
    controller = new AbortController();
    const id = ++requestId;
    try {
      const result = await fetchItems(q, controller.signal);
      if (id !== requestId) return null; // пока ждали, пользователь ввёл другое
      lastQuery = q;
      show(result);
      return result;
    } catch (err) {
      if (err.name === 'AbortError' || id !== requestId) return null;
      showMessage('Не удалось выполнить поиск. Попробуйте ещё раз.');
      return null;
    }
  }

  const debouncedQuery = debounce(query, delay);

  input.addEventListener('input', () => {
    requestId += 1; // инвалидируем ответ, который ещё в пути
    controller?.abort();
    if (input.value.trim().length < minLength) {
      debouncedQuery.cancel();
      items = [];
      close();
      return;
    }
    debouncedQuery(input.value);
  });

  input.addEventListener('keydown', (event) => {
    if (event.key === 'ArrowDown' && items.length) {
      event.preventDefault();
      if (list.hidden) open();
      setActive((active + 1) % items.length);
    } else if (event.key === 'ArrowUp' && items.length) {
      event.preventDefault();
      if (list.hidden) open();
      setActive((active - 1 + items.length) % items.length);
    } else if (event.key === 'Escape' && !list.hidden) {
      event.preventDefault();
      close();
    }
  });

  input.addEventListener('focus', () => {
    if (items.length && lastQuery === input.value.trim()) open();
  });

  document.addEventListener('click', (event) => {
    if (event.target !== input && !list.contains(event.target)) close();
  });

  /** Enter: выбрать подсвеченный вариант, иначе — первый (при необходимости дождаться поиска). */
  async function submit() {
    debouncedQuery.cancel();
    if (active >= 0) {
      choose(active);
      return;
    }
    if (items.length && lastQuery === input.value.trim()) {
      choose(0);
      return;
    }
    const result = await query(input.value);
    if (result?.length) choose(0);
  }

  return { submit, close };
}
