/**
 * Отрисовка. Весь текст из API попадает в DOM только через textContent / createTextNode,
 * поэтому XSS через название города невозможен.
 */
import {
  UNITS, formatTemp, formatHourLabel, formatWeekday, formatDate, formatClock,
  windDirection, hPaToMmHg, uvLabel, rangePosition,
} from './format.js';
import { getWeatherInfo } from './weather-codes.js';
import { placeId } from './model.js';

/** Мини-хелпер для создания элементов: h('div', {class: 'x'}, 'текст', child). */
export function h(tag, props = {}, ...children) {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (value == null || value === false) continue;
    if (key === 'class') el.className = value;
    else if (key === 'style') {
      for (const [prop, val] of Object.entries(value)) el.style.setProperty(prop, val);
    } else if (key.startsWith('on') && typeof value === 'function') {
      el.addEventListener(key.slice(2), value);
    } else el.setAttribute(key, value === true ? '' : String(value));
  }
  for (const child of children.flat()) {
    if (child == null || child === false) continue;
    el.append(child.nodeType ? child : document.createTextNode(String(child)));
  }
  return el;
}

/** «Московская область, Россия» — без повторов названия города. */
export function placeSubtitle(place) {
  return [place.region, place.country]
    .filter((part, i, all) => part && part !== place.name && all.indexOf(part) === i)
    .join(', ');
}

export function renderSkeleton() {
  const block = (cls) => h('div', { class: `skeleton__block ${cls}` });
  return h('div', { class: 'skeleton', 'aria-hidden': 'true' },
    block('skeleton__hero'),
    block('skeleton__row'),
    h('div', { class: 'skeleton__grid' }, block('skeleton__col'), block('skeleton__col')));
}

export function renderError(message, onRetry) {
  return h('section', { class: 'card state-card', role: 'alert' },
    h('h2', { class: 'state-card__title' }, 'Не удалось загрузить прогноз'),
    h('p', {}, message),
    h('button', { type: 'button', class: 'btn', onclick: onRetry }, 'Повторить'));
}

export function renderFavorites(container, favorites, activeId, { onSelect, onRemove }) {
  container.hidden = favorites.length === 0;
  container.replaceChildren(
    h('ul', { class: 'chips' }, favorites.map((fav) => {
      const active = placeId(fav) === activeId;
      return h('li', { class: `chip${active ? ' is-active' : ''}` },
        h('button', {
          type: 'button', class: 'chip__main', 'aria-current': active ? 'true' : null,
          onclick: () => onSelect(fav),
        }, fav.name),
        h('button', {
          type: 'button', class: 'chip__remove', 'aria-label': `Убрать ${fav.name} из избранного`,
          onclick: () => onRemove(fav),
        }, '×'));
    })));
}

function renderHero(data, { place, units, isFavorite, onToggleFavorite }) {
  const { current, daily } = data;
  const today = daily[0];
  const info = getWeatherInfo(current.code, current.isDay);
  const subtitle = placeSubtitle(place);

  const favBtn = h('button', {
    type: 'button',
    class: 'fav-btn',
    'aria-pressed': String(isFavorite),
    title: isFavorite ? 'Убрать из избранного' : 'Добавить в избранное',
    onclick: () => onToggleFavorite(favBtn),
  }, h('span', { 'aria-hidden': 'true' }, '★'), h('span', { class: 'sr-only' }, 'Избранное'));

  return h('section', { class: 'card hero', 'aria-labelledby': 'place-name' },
    h('div', { class: 'hero__head' },
      h('div', {},
        h('h1', { id: 'place-name', class: 'hero__place' }, place.name),
        h('p', { class: 'hero__meta' },
          [subtitle, `${formatDate(current.time)}, ${formatClock(current.time)}`].filter(Boolean).join(' · '))),
      favBtn),
    h('div', { class: 'hero__main' },
      h('span', { class: 'hero__icon', 'aria-hidden': 'true' }, info.icon),
      h('p', { class: 'hero__temp' },
        h('span', { class: 'sr-only' }, 'Температура '),
        formatTemp(current.temp),
        h('span', { class: 'hero__unit' }, UNITS[units].temp.replace('°', ''))),
      h('div', { class: 'hero__text' },
        h('p', { class: 'hero__label' }, info.label),
        h('p', { class: 'hero__sub' }, `Ощущается как ${formatTemp(current.feelsLike)}`),
        h('p', { class: 'hero__sub' }, `Макс. ${formatTemp(today.max)} · мин. ${formatTemp(today.min)}`))));
}

function renderHourly(hourly) {
  return h('section', { class: 'card', 'aria-labelledby': 'hourly-title' },
    h('h2', { id: 'hourly-title', class: 'card__title' }, 'Почасовой прогноз'),
    h('ol', { class: 'hourly' }, hourly.map((hour, i) => {
      const info = getWeatherInfo(hour.code, hour.isDay);
      return h('li', { class: 'hourly__item' },
        h('span', { class: 'hourly__time' }, formatHourLabel(hour.time, i)),
        h('span', { class: 'hourly__icon', role: 'img', 'aria-label': info.label }, info.icon),
        h('span', { class: 'hourly__temp' }, formatTemp(hour.temp)),
        h('span', { class: 'hourly__precip' }, hour.precip >= 20 ? `${hour.precip}%` : ''));
    })));
}

function renderDaily(daily) {
  const weekMin = Math.min(...daily.map((d) => d.min));
  const weekMax = Math.max(...daily.map((d) => d.max));

  return h('section', { class: 'card', 'aria-labelledby': 'daily-title' },
    h('h2', { id: 'daily-title', class: 'card__title' }, 'Прогноз на 7 дней'),
    h('ul', { class: 'daily' }, daily.map((day, i) => {
      const info = getWeatherInfo(day.code, true);
      const { left, width } = rangePosition(day.min, day.max, weekMin, weekMax);
      return h('li', { class: 'daily__item' },
        h('span', { class: 'daily__day' }, formatWeekday(day.date, i)),
        h('span', { class: 'daily__icon', role: 'img', 'aria-label': info.label }, info.icon),
        h('span', { class: 'daily__precip' }, day.precip >= 20 ? `${day.precip}%` : ''),
        h('span', { class: 'daily__min' }, formatTemp(day.min)),
        h('span', { class: 'range', 'aria-hidden': 'true' },
          h('span', { class: 'range__fill', style: { left: `${left}%`, width: `${width}%` } })),
        h('span', { class: 'daily__max' }, formatTemp(day.max)));
    })));
}

function renderDetails(data, units) {
  const { current, daily } = data;
  const today = daily[0];
  const tiles = [
    ['Ощущается как', formatTemp(current.feelsLike)],
    ['Влажность', `${Math.round(current.humidity)}%`],
    ['Ветер', `${Math.round(current.windSpeed)} ${UNITS[units].speed}`, windDirection(current.windDir)],
    ['Давление', `${hPaToMmHg(current.pressure)} мм рт. ст.`],
    ['УФ-индекс', String(Math.round(today.uv ?? 0)), uvLabel(today.uv)],
    ['Осадки', `${today.precip ?? 0}%`, 'вероятность'],
    ['Восход', formatClock(today.sunrise)],
    ['Закат', formatClock(today.sunset)],
  ];

  return h('section', { class: 'card', 'aria-labelledby': 'details-title' },
    h('h2', { id: 'details-title', class: 'card__title' }, 'Подробнее'),
    h('dl', { class: 'details' }, tiles.map(([label, value, hint]) =>
      h('div', { class: 'details__tile' },
        h('dt', {}, label),
        h('dd', {}, value, hint ? h('span', { class: 'details__hint' }, hint) : null)))));
}

/** Собирает всю страницу прогноза. */
export function renderWeather(data, context) {
  const fragment = document.createDocumentFragment();
  fragment.append(
    renderHero(data, context),
    renderHourly(data.hourly),
    h('div', { class: 'grid' }, renderDaily(data.daily), renderDetails(data, context.units)));
  return fragment;
}
