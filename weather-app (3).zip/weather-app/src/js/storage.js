/** Обёртка над localStorage: не падает в приватном режиме или при переполнении. */
const PREFIX = 'weather-app:';

export function load(key, fallback) {
  try {
    const value = localStorage.getItem(PREFIX + key);
    return value === null ? fallback : JSON.parse(value);
  } catch {
    return fallback;
  }
}

export function save(key, value) {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value));
  } catch {
    /* хранилище недоступно — приложение продолжает работать без сохранения */
  }
}
