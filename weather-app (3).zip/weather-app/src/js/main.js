import { getForecast, reverseGeocode, searchCities } from './api.js';
import { UNITS, formatTemp } from './format.js';
import { placeId } from './model.js';
import { getWeatherInfo } from './weather-codes.js';
import * as storage from './storage.js';
import { createAutocomplete } from './autocomplete.js';
import { h, placeSubtitle, renderError, renderFavorites, renderSkeleton, renderWeather } from './ui.js';

const DEFAULT_PLACE = {
  name: 'Москва', region: 'Москва', country: 'Россия', latitude: 55.7558, longitude: 37.6173,
};
const MAX_FAVORITES = 8;

const $ = (selector) => document.querySelector(selector);
const els = {
  form: $('#search-form'),
  input: $('#search-input'),
  suggestions: $('#suggestions'),
  geo: $('#geo-btn'),
  theme: $('#theme-btn'),
  units: [...document.querySelectorAll('[data-units]')],
  favorites: $('#favorites'),
  status: $('#status'),
  content: $('#content'),
};

const isValidPlace = (p) =>
  Boolean(p) && typeof p.name === 'string' && Number.isFinite(p.latitude) && Number.isFinite(p.longitude);

// Данные из localStorage — недоверенный ввод: проверяем форму перед использованием.
const storedPlace = storage.load('place', null);
const storedFavorites = storage.load('favorites', []);
const storedUnits = storage.load('units', 'metric');

const state = {
  units: storedUnits in UNITS ? storedUnits : 'metric',
  theme: ['light', 'dark'].includes(storage.load('theme', null)) ? storage.load('theme', null) : null,
  place: isValidPlace(storedPlace) ? storedPlace : DEFAULT_PLACE,
  favorites: Array.isArray(storedFavorites) ? storedFavorites.filter(isValidPlace).slice(0, MAX_FAVORITES) : [],
  controller: null,
};

const systemDark = window.matchMedia('(prefers-color-scheme: dark)');

function setStatus(text) {
  els.status.textContent = text;
}

/* ---------- Тема и единицы ---------- */

function effectiveTheme() {
  return state.theme ?? (systemDark.matches ? 'dark' : 'light');
}

function applyTheme() {
  if (state.theme) document.documentElement.dataset.theme = state.theme;
  else delete document.documentElement.dataset.theme;
}

els.theme.addEventListener('click', () => {
  state.theme = effectiveTheme() === 'dark' ? 'light' : 'dark';
  storage.save('theme', state.theme);
  applyTheme();
});

function applyUnitsButtons() {
  els.units.forEach((btn) => btn.setAttribute('aria-pressed', String(btn.dataset.units === state.units)));
}

els.units.forEach((btn) => btn.addEventListener('click', () => {
  if (btn.dataset.units === state.units) return;
  state.units = btn.dataset.units;
  storage.save('units', state.units);
  applyUnitsButtons();
  loadWeather();
}));

/* ---------- Избранное ---------- */

const isFavorite = (place) => state.favorites.some((f) => placeId(f) === placeId(place));

function drawFavorites() {
  renderFavorites(els.favorites, state.favorites, placeId(state.place), {
    onSelect: (place) => loadWeather(place),
    onRemove: (place) => {
      state.favorites = state.favorites.filter((f) => placeId(f) !== placeId(place));
      storage.save('favorites', state.favorites);
      drawFavorites();
      const star = $('.fav-btn');
      if (star && placeId(place) === placeId(state.place)) syncStar(star);
    },
  });
}

function syncStar(button) {
  const fav = isFavorite(state.place);
  button.setAttribute('aria-pressed', String(fav));
  button.title = fav ? 'Убрать из избранного' : 'Добавить в избранное';
}

function toggleFavorite(button) {
  if (isFavorite(state.place)) {
    state.favorites = state.favorites.filter((f) => placeId(f) !== placeId(state.place));
    setStatus(`${state.place.name} убран из избранного`);
  } else if (state.favorites.length >= MAX_FAVORITES) {
    setStatus(`В избранном может быть не больше ${MAX_FAVORITES} городов`);
    return;
  } else {
    state.favorites = [...state.favorites, state.place];
    setStatus(`${state.place.name} добавлен в избранное`);
  }
  storage.save('favorites', state.favorites);
  syncStar(button);
  drawFavorites();
}

/* ---------- Загрузка и отображение прогноза ---------- */

async function loadWeather(place = state.place) {
  state.controller?.abort(); // устаревший запрос больше не нужен
  const controller = new AbortController();
  state.controller = controller;

  state.place = place;
  storage.save('place', place);
  drawFavorites();

  els.content.setAttribute('aria-busy', 'true');
  els.content.replaceChildren(renderSkeleton());
  setStatus(`Загружаем прогноз для города ${place.name}…`);

  try {
    const data = await getForecast(place, state.units, controller.signal);
    if (controller.signal.aborted) return;

    const info = getWeatherInfo(data.current.code, data.current.isDay);
    document.body.dataset.weather = info.theme;
    document.title = `${formatTemp(data.current.temp)} ${place.name} — Погода`;

    els.content.replaceChildren(renderWeather(data, {
      place,
      units: state.units,
      isFavorite: isFavorite(place),
      onToggleFavorite: toggleFavorite,
    }));
    setStatus(`${place.name}: ${formatTemp(data.current.temp)}, ${info.label}`);
  } catch (err) {
    if (err.name === 'AbortError') return;
    const message = err.name === 'ApiError' ? err.message : 'Произошла непредвиденная ошибка.';
    els.content.replaceChildren(renderError(message, () => loadWeather(place)));
    setStatus('Не удалось загрузить прогноз');
  } finally {
    if (state.controller === controller) els.content.setAttribute('aria-busy', 'false');
  }
}

/* ---------- Поиск города ---------- */

const autocomplete = createAutocomplete({
  input: els.input,
  list: els.suggestions,
  fetchItems: searchCities,
  renderItem: (city) => [
    h('span', { class: 'suggestions__name' }, city.name),
    h('span', { class: 'suggestions__sub' }, placeSubtitle(city)),
  ],
  onSelect: (city) => {
    els.input.value = '';
    els.input.blur();
    loadWeather(city);
  },
});

els.form.addEventListener('submit', (event) => {
  event.preventDefault();
  autocomplete.submit();
});

/* ---------- Геолокация ---------- */

const GEO_ERRORS = {
  1: 'Доступ к геолокации запрещён. Разрешите его в настройках браузера или найдите город вручную.',
  2: 'Не удалось определить местоположение. Найдите город вручную.',
  3: 'Определение местоположения заняло слишком много времени. Попробуйте ещё раз.',
};

function locate() {
  if (!('geolocation' in navigator)) {
    setStatus('Ваш браузер не поддерживает геолокацию');
    return;
  }
  els.geo.disabled = true;
  setStatus('Определяем ваше местоположение…');

  navigator.geolocation.getCurrentPosition(
    async ({ coords }) => {
      const geo = await reverseGeocode(coords.latitude, coords.longitude).catch(() => null);
      els.geo.disabled = false;
      loadWeather({
        name: geo?.name || 'Моё местоположение',
        region: geo?.region ?? '',
        country: geo?.country ?? '',
        latitude: coords.latitude,
        longitude: coords.longitude,
      });
    },
    (err) => {
      els.geo.disabled = false;
      const message = GEO_ERRORS[err.code] ?? GEO_ERRORS[2];
      setStatus(message);
      els.content.replaceChildren(renderError(message, locate));
    },
    { timeout: 10_000, maximumAge: 5 * 60 * 1000 },
  );
}

els.geo.addEventListener('click', locate);

/* ---------- Старт ---------- */

applyTheme();
applyUnitsButtons();
loadWeather();
