// Выполняется до отрисовки страницы, чтобы не было «вспышки» неправильной темы.
try {
  const theme = JSON.parse(localStorage.getItem('weather-app:theme'));
  if (theme === 'light' || theme === 'dark') {
    document.documentElement.dataset.theme = theme;
  }
} catch {
  /* localStorage недоступен — остаёмся на системной теме */
}
