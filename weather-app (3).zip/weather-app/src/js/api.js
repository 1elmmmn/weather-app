import { normalizeForecast, placeId } from './model.js';
import { UNITS } from './format.js';

const GEO_URL = 'https://geocoding-api.open-meteo.com/v1/search';
const FORECAST_URL = 'https://api.open-meteo.com/v1/forecast';
const REVERSE_URL = 'https://api.bigdatacloud.net/data/reverse-geocode-client';

const CACHE_TTL_MS = 10 * 60 * 1000;
const cache = new Map();

export class ApiError extends Error {
  constructor(message, { status, cause } = {}) {
    super(message, { cause });
    this.name = 'ApiError';
    this.status = status;
  }
}

async function getJson(url, signal) {
  let response;
  try {
    response = await fetch(url, { signal });
  } catch (err) {
    if (err.name === 'AbortError') throw err; // отмена — не ошибка для пользователя
    throw new ApiError('Нет соединения с сервером погоды. Проверьте интернет.', { cause: err });
  }
  if (!response.ok) {
    throw new ApiError(`Сервис погоды вернул ошибку (${response.status}). Попробуйте позже.`, {
      status: response.status,
    });
  }
  return response.json();
}

/** Поиск городов по названию. Пустой запрос и запрос из 1 символа не уходят в сеть. */
export async function searchCities(query, signal) {
  const name = query.trim();
  if (name.length < 2) return [];

  const params = new URLSearchParams({ name, count: '6', language: 'ru', format: 'json' });
  const data = await getJson(`${GEO_URL}?${params}`, signal);

  return (data.results ?? []).map((r) => ({
    name: r.name,
    region: r.admin1 ?? '',
    country: r.country ?? '',
    latitude: r.latitude,
    longitude: r.longitude,
  }));
}

/** Прогноз по месту; ответы кэшируются на 10 минут. */
export async function getForecast(place, units, signal) {
  const key = `${placeId(place)}|${units}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < CACHE_TTL_MS) return hit.data;

  const params = new URLSearchParams({
    latitude: String(place.latitude),
    longitude: String(place.longitude),
    current: [
      'temperature_2m', 'apparent_temperature', 'relative_humidity_2m', 'is_day',
      'weather_code', 'wind_speed_10m', 'wind_direction_10m', 'surface_pressure',
    ].join(','),
    hourly: 'temperature_2m,weather_code,precipitation_probability,is_day',
    daily: [
      'weather_code', 'temperature_2m_max', 'temperature_2m_min', 'sunrise', 'sunset',
      'uv_index_max', 'precipitation_probability_max',
    ].join(','),
    timezone: 'auto',
    forecast_days: '7',
    temperature_unit: UNITS[units].apiTemp,
    wind_speed_unit: UNITS[units].apiWind,
  });

  const raw = await getJson(`${FORECAST_URL}?${params}`, signal);
  const data = normalizeForecast(raw);
  cache.set(key, { at: Date.now(), data });
  return data;
}

/** Название населённого пункта по координатам; при любой ошибке — null. */
export async function reverseGeocode(latitude, longitude, signal) {
  try {
    const params = new URLSearchParams({
      latitude: String(latitude),
      longitude: String(longitude),
      localityLanguage: 'ru',
    });
    const data = await getJson(`${REVERSE_URL}?${params}`, signal);
    return {
      name: data.city || data.locality || null,
      region: data.principalSubdivision ?? '',
      country: data.countryName ?? '',
    };
  } catch (err) {
    if (err.name === 'AbortError') throw err;
    return null;
  }
}

export function clearCache() {
  cache.clear();
}
